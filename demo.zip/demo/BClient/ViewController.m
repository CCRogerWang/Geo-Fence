//
//  ViewController.m
//  BClient
//
//  Created by Roger on 2016/5/2.
//  Copyright © 2016年 Roger. All rights reserved.
//

#import "ViewController.h"
#import <GoogleMaps/GoogleMaps.h>

@interface ViewController ()
<GMSMapViewDelegate>
{
    GMSMapView *_mapView;
    NSMutableArray *_markers;
    GMSPolygon *_polygon;
    
    NSMutableArray *_targets;
    
    GMSPolygon *_deletegon;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _markers = [NSMutableArray new];
    _targets = [NSMutableArray new];
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:1.285
        longitude:103.848                                                       zoom:16];
    _mapView = [GMSMapView mapWithFrame:CGRectZero camera:camera];
    _mapView.delegate = self;
    self.view = _mapView;
    
    [self addTarget:CLLocationCoordinate2DMake(1.285, 103.848)];
    
    [self drawDeleteArea];
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)drawDeleteArea{
    if (_deletegon) {
        _deletegon.map = nil;
    }
    CGPoint topLeftPoint = CGPointMake(0, _mapView.frame.size.height-100);
    CLLocationCoordinate2D topLeftLocation =
    [_mapView.projection coordinateForPoint: topLeftPoint];
    
    CGPoint bottomRightPoint =
    CGPointMake(_mapView.frame.size.width, _mapView.frame.size.height);
    CLLocationCoordinate2D bottomRightLocation =
    [_mapView.projection coordinateForPoint: bottomRightPoint];
    
    CGPoint topRightPoint = CGPointMake(_mapView.frame.size.width, _mapView.frame.size.height-100);
    CLLocationCoordinate2D topRightLocation =
    [_mapView.projection coordinateForPoint: topRightPoint];
    
    CGPoint bottomLeftPoint =
    CGPointMake(0, _mapView.frame.size.height);
    CLLocationCoordinate2D bottomLeftLocation =
    [_mapView.projection coordinateForPoint: bottomLeftPoint];
    
    GMSVisibleRegion realVisibleRegion;
    realVisibleRegion.farLeft = topLeftLocation;
    realVisibleRegion.farRight = topRightLocation;
    realVisibleRegion.nearLeft = bottomLeftLocation;
    realVisibleRegion.nearRight = bottomRightLocation;
    
    
    GMSMutablePath *poly = [GMSMutablePath path];
    
    [poly addCoordinate:topLeftLocation];
    [poly addCoordinate:topRightLocation];
    [poly addCoordinate:bottomRightLocation];
    [poly addCoordinate:bottomLeftLocation];
    
    
    // Create the polygon, and assign it to the map.
    _deletegon = [GMSPolygon polygonWithPath:poly];
    _deletegon.fillColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:0.3];
    _deletegon.strokeColor = [UIColor redColor];
    _deletegon.strokeWidth = 2;
    _deletegon.map = _mapView;
}
- (void)removeTargets{
    if (_targets.count > 0) {
        
    }
    [_targets removeAllObjects];
}
- (void)removeMarkers{
    if (_markers.count > 0) {
        for (GMSMarker *marker in _markers) {
            marker.map = nil;
        }
    }
    [_markers removeAllObjects];
}
- (void)detectToDelete:(GMSMarker*)marker{
    
    if (GMSGeometryContainsLocation(marker.position, _deletegon.path, YES)) {
        for (GMSMarker*m in _markers) {
            if (m == marker) {
                [_markers removeObject:m];
                break;
            }
        }
        marker.map = nil;
        [self drawPoly];
    } else {
        
    }
}
- (void)detectPoly{
    GMSMarker *marker = [_targets firstObject];
    if (GMSGeometryContainsLocation(marker.position, _polygon.path, YES)) {
        NSLog(@"YES: you are in this polygon.");
        marker.icon = [GMSMarker markerImageWithColor:[UIColor greenColor]];
    } else {
        NSLog(@"You do not appear to be in this polygon.");
        marker.icon = [GMSMarker markerImageWithColor:[UIColor redColor]];
    }
}
- (void)drawPoly{
    if (_polygon) {
        _polygon.map = nil;
    }
    GMSMutablePath *poly = [GMSMutablePath path];
    for (GMSMarker *marker in _markers) {
        [poly addCoordinate:marker.position];
    }
    
    // Create the polygon, and assign it to the map.
    _polygon = [GMSPolygon polygonWithPath:poly];
    _polygon.fillColor = [UIColor colorWithRed:0 green:0 blue:1 alpha:0.3];
    _polygon.strokeColor = [UIColor blueColor];
    _polygon.strokeWidth = 2;
    _polygon.map = _mapView;
    
    
    
    [self detectPoly];
}
- (void)addTarget:(CLLocationCoordinate2D)coordinate{
    GMSMarker *marker = [GMSMarker markerWithPosition:coordinate];
    marker.title = @"Target";
    marker.map = _mapView;
    [_targets addObject:marker];
}
- (void)addMarker:(CLLocationCoordinate2D)coordinate{
    GMSMarker *marker = [GMSMarker markerWithPosition:coordinate];
    marker.title = @"Fence";
    marker.map = _mapView;
    [marker setDraggable: YES];
    [_markers addObject:marker];
    if(_markers.count >= 3){
        [self drawPoly];
    }
}

- (IBAction)deleteAll:(id)sender {
}
#pragma mark - GMSMapViewDelegate

- (void)mapView:(GMSMapView *)mapView
didTapAtCoordinate:(CLLocationCoordinate2D)coordinate {
//    NSLog(@"You tapped at %f,%f", coordinate.latitude, coordinate.longitude);
    [self addMarker:coordinate];
}
- (void)mapView:(GMSMapView *)mapView didDragMarker:(GMSMarker *)marker{
    [self drawPoly];
    [self drawDeleteArea];
}

- (void)mapView:(GMSMapView *)mapView didChangeCameraPosition:(GMSCameraPosition *)position{
    
}
- (void)mapView:(GMSMapView *)mapView didEndDraggingMarker:(GMSMarker *)marker{
    [self detectToDelete:marker];
    if (_deletegon) {
        _deletegon.map = nil;
    }
}
@end
