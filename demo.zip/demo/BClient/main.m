//
//  main.m
//  BClient
//
//  Created by Roger on 2016/5/2.
//  Copyright © 2016年 Roger. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
